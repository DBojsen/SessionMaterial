import tl = require('azure-pipelines-task-lib/task');
import * as azdev from "azure-devops-node-api";
import webClient = require("azure-pipelines-tasks-azure-arm-rest-v2/webClient");

async function checkLicense(checkLicenseKey: string): Promise<Boolean> {
    var httpRequest = new webClient.WebRequest();
    httpRequest.method = 'POST';
    httpRequest.headers = {
        'content-type': 'application/json'
    };
    httpRequest.uri = 'https://passlicensingengine.azurewebsites.net/api/ValidatePASSLicense?code=d21Fu1w4kh1PkjiwZmuQVoHBHRwP_Q0tnijgm6I2vDBYAzFuV2CLAQ==';
    httpRequest.body = JSON.stringify({
        licenseKey: checkLicenseKey
    });

    let response = await webClient.sendRequest(httpRequest);

    if (response.statusCode == 200) {
        return true;
    } else {
        return false;
    }
}

async function run() {
    try {
        let collectionUri = tl.getVariable('System.CollectionUri');
        let accessToken = tl.getEndpointAuthorizationParameter('SystemVssConnection', 'AccessToken', false);
        let authHandler = azdev.getPersonalAccessTokenHandler(accessToken!);
        let connection = new azdev.WebApi(collectionUri!, authHandler);
        let extensionManagementApi = await connection.getExtensionManagementApi();
        let licenseDocument = await extensionManagementApi.getDocumentByName(
            'DavidBojsen',
            'dbojsen-pass-demo-build-release-task',
            'Default',
            'Current',
            '$settings',
            'PASSLicense');

        let licenseKey = licenseDocument.value;

        if (licenseKey == undefined) {
            tl.setResult(tl.TaskResult.Failed, 'License key is not supplied');
            return;
        } else {
            let licenseValid = await checkLicense(licenseKey);

            if (!licenseValid) {
                tl.setResult(tl.TaskResult.Failed, 'License key is not valid');
                return;
            }
        }

        const inputString: string | undefined = tl.getInput('samplestring', true);
        if (inputString == 'bad') {
            tl.setResult(tl.TaskResult.Failed, 'Bad input was given');
            return;
        }
        console.log('Hello', inputString);
    }
    catch (err) {
        if (err instanceof Error) {
            tl.setResult(tl.TaskResult.Failed, err.message);
        } else {
            tl.setResult(tl.TaskResult.Failed, 'Unexpected error');
        }
    }
}

run();